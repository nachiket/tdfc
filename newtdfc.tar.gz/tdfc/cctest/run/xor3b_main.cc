#define XOR3_NAME xor3b
#include "xor3b.h"
#include "xor3_main_body.cc"
