#define XOR3_NAME xor3c
#include "xor3c.h"
#include "xor3_main_body.cc"

