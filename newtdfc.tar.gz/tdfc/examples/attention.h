// Standard attention signals

#define ATTN_ERROR	0
#define ATTN_DONE	1
